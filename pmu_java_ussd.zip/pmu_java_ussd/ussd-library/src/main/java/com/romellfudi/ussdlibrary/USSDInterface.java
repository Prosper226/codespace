package com.romellfudi.ussdlibrary;

/* loaded from: classes.dex */
public interface USSDInterface {
    void sendData(String str);
}
